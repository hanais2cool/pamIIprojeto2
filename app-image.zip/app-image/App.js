import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Sharing from 'expo-sharing';
import * as ImageManipulator from "expo-image-manipulator";
import styled from 'styled-components/native';

const Container = styled.View`
    flex: 1;
    align-items: center;
    justify-content: center;
`;
const Title = styled.Text`
    color: red;
    font-size: 30px;
    text-align: center;
    margin: 15px;
`;
const Inst = styled.Text`
    color: #888;
    font-size: 30px;
    text-align: center;
    margin: 15px;
`;
const Img = styled.Image`
    width: 400;
    height: 400;
    alignSelft: center;
`;
const ImgThumb = styled.Image`
    width: 700;
    height: 700;
    alignSelft: center;
`;
const CheckButton = styled.TouchableOpacity`
    width: 400px;
    height: 100px;
    border-width: 2px;
    border-radius: 20px;
    alignSelft: center;
    justify-content: center;
    background-color: red;
`;

const TextButton = styled.Text`
    color: black;
    font-size: 30px;
    text-align: center;
`;

export default function App() {
  const [selectedImage, setSelectedImage] = React.useState(null);

   let openImagePickerAsync = async () => {    
    let pickerResult = await ImagePicker.launchImageLibraryAsync();
    console.log(pickerResult);
    setSelectedImage({ localUri: pickerResult.uri });
   };
  let openShareDialogAsync = async () => {
    if (Platform.OS === 'web') {
      alert(`Vish! Esse compartilhamento está disponível apenas para Mobile!`);
      return;
    }
    const imageTmp = await ImageManipulator.manipulateAsync(selectedImage.localUri);
    await Sharing.shareAsync(imageTmp.uri);
  };

  if (selectedImage !== null) {
    return (
      <Container>
        <ImgThumb source={{ uri: selectedImage.localUri }} />
        <CheckButton onPress={openShareDialogAsync} >
          <TextButton>Partilhar</TextButton>
        </CheckButton>
      </Container>
    );
  }

  return (
    <Container>
      <Title>
        Partilhamento de imagens
      </Title>
      <Img source={{ uri: 'https://img.freepik.com/premium-vector/camera-icon-symbol-template-camera-outline-icon-isolated-white-background_664675-534.jpg?w=2000' }} />
      <Inst>
        Partilhe suas fotos quando quiser ao clicar no botão:
      </Inst>
      <CheckButton onPress={openImagePickerAsync}>
        <TextButton>Escolha uma foto</TextButton>
      </CheckButton>
    </Container>
  );
}

